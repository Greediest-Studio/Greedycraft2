#version 130 

#define ONEHUNDREDONE
#define FSH

#define GBUFFERS_SKYTEXTURED

#include "/program/gbuffers_skytextured.glsl"

