#version 130 

#define GBUFFERS_ENTITIES_GLOWING
#define ONEHUNDREDONE
#define VSH

#include "/program/gbuffers_entities.glsl"

