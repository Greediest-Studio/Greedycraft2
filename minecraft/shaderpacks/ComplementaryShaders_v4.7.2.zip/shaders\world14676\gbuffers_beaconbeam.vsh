#version 130 

#define SEVENTYEIGHT
#define DIM14676
#define VSH

#include "/program/gbuffers_beaconbeam.glsl"

