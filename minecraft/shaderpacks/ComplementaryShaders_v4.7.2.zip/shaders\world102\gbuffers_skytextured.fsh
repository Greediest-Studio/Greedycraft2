#version 130 

#define ONEHUNDREDTWO
#define FSH

#define GBUFFERS_SKYTEXTURED

#include "/program/gbuffers_skytextured.glsl"

