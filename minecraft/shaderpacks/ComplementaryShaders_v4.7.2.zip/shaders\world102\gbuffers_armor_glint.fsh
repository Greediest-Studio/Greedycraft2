#version 130 

#define ONEHUNDREDTWO
#define FSH

#include "/program/gbuffers_armor_glint.glsl"

