#version 130 

#define ONEHUNDRED
#define VSH

#define GBUFFERS_SKYTEXTURED

#include "/program/gbuffers_skytextured.glsl"

