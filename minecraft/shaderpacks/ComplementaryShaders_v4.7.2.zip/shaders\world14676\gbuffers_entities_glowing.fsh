#version 130 

#define GBUFFERS_ENTITIES
#define GBUFFERS_ENTITIES_GLOWING
#define SEVENTYEIGHT
#define DIM14676
#define FSH

#include "/program/gbuffers_entities.glsl"

