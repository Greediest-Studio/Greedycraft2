#version 130 
#define OVERWORLD

#define SEVENTYEIGHT
#define DIM14676
#define VSH

#include "/program/deferred1.glsl"

