#version 130

#define ONEHUNDRED
#define VSH

#include "/program/gbuffers_skybasic.glsl"

