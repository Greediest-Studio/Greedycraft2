#version 130 

#define GBUFFERS_BLOCK
#define SEVENTYEIGHT
#define DIM14676
#define FSH

#include "/program/gbuffers_block.glsl"

