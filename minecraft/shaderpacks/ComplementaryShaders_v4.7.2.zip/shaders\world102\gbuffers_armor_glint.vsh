#version 130 

#define ONEHUNDREDTWO
#define VSH

#include "/program/gbuffers_armor_glint.glsl"

