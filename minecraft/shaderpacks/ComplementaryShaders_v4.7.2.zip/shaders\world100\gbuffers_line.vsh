#version 130 

#define ONEHUNDRED
#define VSH
#define GBUFFERS_LINE

#include "/program/gbuffers_basic.glsl"

