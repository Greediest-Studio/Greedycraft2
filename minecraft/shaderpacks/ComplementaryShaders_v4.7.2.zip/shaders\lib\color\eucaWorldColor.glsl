// Dimension 820 euca world color overrides
// Includes after lightColor.glsl to provide euca-specific colors

// Euca world base color (used in fog, sky, reflections)
vec3 eucaWorldCol = vec3(0.855, 0.996, 0.533); // #DAFE88
