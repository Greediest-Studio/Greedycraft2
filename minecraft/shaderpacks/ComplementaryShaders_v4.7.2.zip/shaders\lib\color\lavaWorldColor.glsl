// Dimension 822 lava world color overrides
// Includes after lightColor.glsl to provide lava-specific colors

// Lava world base color (used in fog, sky, reflections)
vec3 lavaWorldCol = vec3(0.18, 0.07, 0.03);
