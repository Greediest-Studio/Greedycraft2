#version 130 
#define OVERWORLD

#define DEFERRED
#define SEVENTYEIGHT
#define DIM14676
#define FSH

#include "/program/deferred1.glsl"

