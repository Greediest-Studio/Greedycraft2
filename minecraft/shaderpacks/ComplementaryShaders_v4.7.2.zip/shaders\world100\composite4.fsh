#version 130 

#define ONEHUNDRED
#define FSH

#include "/program/composite4.glsl"

