#version 130

#define SEVENTYEIGHT
#define DIM14676
#define FSH

#include "/program/composite1.glsl"

