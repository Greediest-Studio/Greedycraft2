#version 130 

#define ONEHUNDREDONE
#define VSH

#include "/program/gbuffers_armor_glint.glsl"

