#version 130 
#define OVERWORLD

#define DEFERRED
#define ONEHUNDREDTWO
#define FSH

#include "/program/deferred1.glsl"
