#version 130 

#define ONEHUNDREDTWO
#define FSH
#define GBUFFERS_LINE

#include "/program/gbuffers_basic.glsl"

