vec3 GetSkyColor(vec3 lightCol, float NdotU, vec3 nViewPos, bool isReflection) {
    #ifdef DIM14676
        return vec3(0.0);
    #endif

    #ifdef SEVENTYEIGHT
        float skyMix78 = clamp(NdotU * 0.5 + 0.5, 0.0, 1.0);
        vec3 skyBottom78 = vec3(0.004, 0.010, 0.028);
        vec3 skyTop78 = vec3(0.001, 0.003, 0.012);
        vec3 sky78 = mix(skyBottom78, skyTop78, skyMix78);
        sky78 += pow(1.0 - abs(NdotU), 2.3) * vec3(0.008, 0.018, 0.050);
        return sky78;
    #endif

    #ifdef EIGHTHUNDREDTWENTYTWO
        return lavaWorldCol * 0.12 * (0.4 + 0.6 * max(NdotU, 0.0));
    #endif

    #ifdef EIGHTHUNDREDTWENTYONE
        return vec3(0.0);
    #endif

    #ifdef EIGHTHUNDREDTWENTYSIX
        return vec3(1.0);
    #endif

    #ifdef EIGHTHUNDREDTWENTYNINE
        float skyMix829 = clamp(NdotU * 0.5 + 0.5, 0.0, 1.0);
        vec3 skyBottom829 = vec3(0.020, 0.016, 0.000);
        vec3 skyTop829 = vec3(0.120, 0.090, 0.018);
        vec3 sky829 = mix(skyBottom829, skyTop829, skyMix829);
        sky829 += pow(1.0 - abs(NdotU), 1.6) * vec3(0.035, 0.025, 0.003);
        return sky829;
    #endif

    #ifdef FOURHUNDREDTWENTYFIVE
        float sunVisibility = 0.0;
        float timeBrightness = 0.0;
        float rainStrengthS = 0.0;
    #endif

    #ifdef FOURHUNDREDTWENTYSIX
        float skyMix426 = clamp(NdotU * 0.5 + 0.5, 0.0, 1.0);
        vec3 skyBottom426 = vec3(0.050, 0.075, 0.105);
        vec3 skyTop426 = vec3(0.090, 0.125, 0.165);
        return mix(skyBottom426, skyTop426, skyMix426);
    #endif

    #ifdef FOURHUNDREDTWENTYSEVEN
        float skyMix427 = clamp(NdotU * 0.5 + 0.5, 0.0, 1.0);
        vec3 skyBottom427 = vec3(0.008, 0.002, 0.014);
        vec3 skyTop427 = vec3(0.050, 0.013, 0.082);
        return mix(skyBottom427, skyTop427, skyMix427);
    #endif

    #ifdef FOURHUNDREDTWENTYFOUR
        float skyMix424 = clamp(NdotU * 0.5 + 0.5, 0.0, 1.0);
        vec3 skyBottom424 = vec3(0.000, 0.000, 0.000);
        vec3 skyTop424 = vec3(0.003, 0.004, 0.006);
        return mix(skyBottom424, skyTop424, skyMix424);
    #endif

    #ifdef NILFHEIM
        float skyMix43 = clamp(NdotU * 0.5 + 0.5, 0.0, 1.0);
        vec3 skyBottom43 = vec3(0.006, 0.020, 0.052);
        vec3 skyTop43 = vec3(0.001, 0.004, 0.018);
        vec3 glow43 = pow(1.0 - abs(NdotU), 1.55) * vec3(0.006, 0.032, 0.090);
        vec3 sky43 = mix(skyBottom43, skyTop43, skyMix43) + glow43;

        vec2 crackCoord43 = vec2(dot(nViewPos, normalize(vec3(0.78, 0.0, -0.62))),
                                 dot(nViewPos, normalize(vec3(0.22, 0.94, 0.26))));
        float crackPath43 = crackCoord43.y - crackCoord43.x * 0.46 - 0.15
                          - sin(crackCoord43.x * 18.0) * 0.018
                          - sin(crackCoord43.x * 43.0 + 1.7) * 0.007;
        float crackLength43 = smoothstep(0.62, 0.22, abs(crackCoord43.x + 0.06));
        float crackCore43 = exp(-abs(crackPath43) * 115.0) * crackLength43;
        float crackHalo43 = exp(-abs(crackPath43) * 22.0) * crackLength43;
        float crackBreak43 = 0.72 + 0.28 * sin(crackCoord43.x * 71.0 + sin(crackCoord43.x * 19.0) * 2.0);
        vec3 crackColor43 = vec3(0.020, 0.230, 0.520) * crackHalo43 * 0.30
                          + vec3(0.100, 0.560, 1.000) * crackCore43 * crackBreak43 * 0.95;
        return sky43 + crackColor43;
    #endif

    #ifdef EIGHTHUNDREDTWENTY
        float sunVisibility = 1.0;
        float timeBrightness = 1.0;
        float rainStrengthS = 0.0;
    #endif

    #ifdef EIGHTHUNDREDTWENTYFOUR
        float sunVisibility = 1.0;
        float timeBrightness = 1.0;
        float rainStrengthS = 0.0;
    #endif

    #ifdef EIGHTHUNDREDTWENTYSEVEN
        float sunVisibility = 0.0;
        float timeBrightness = 0.0;
        float rainStrengthS = 0.0;
    #endif

    float timeBrightnessInv = 1.0 - timeBrightness;
    float timeBrightnessInv2 = timeBrightnessInv * timeBrightnessInv;
    float timeBrightnessInv4 = timeBrightnessInv2 * timeBrightnessInv2;
    float timeBrightnessInv8 = timeBrightnessInv4 * timeBrightnessInv4;

    float NdotSp = clamp(dot(nViewPos, sunVec) * 0.5 + 0.5, 0.001, 1.0);
    float NdotS = NdotSp * NdotSp;
    NdotS *= NdotS;

    float absNdotU = abs(NdotU);

    vec3 skyColor2 = skyColor * skyColor;

    vec3 sky = mix(sqrt1(skyColor) * 0.47, skyColor2 * 0.9, absNdotU);
    sky = sky * (0.5 + 0.5 * sunVisibility) * skyMult;

    #ifdef ONESEVEN
        sky = vec3(0.812, 0.741, 0.674) * 0.5;
    #endif

    float horizon = 1.0 - max(NdotU + 0.1, 0.0) * (1.0 - 0.25 * NdotS * sunVisibility);
    horizon = min(horizon, 0.9);
    horizon *= horizon;

    float lightmix = NdotS * max(1.0 - absNdotU * 2.0, 0.0) * 0.5 + horizon + 0.05;
    lightmix *= sunVisibility * (1.0 - rainStrengthS) * timeBrightnessInv8;

    sky *= 2.0 - 0.5 * timeBrightnessInv4;
    sky *= mix(SKY_NOON, SKY_DAY, timeBrightnessInv4);

    float mult = 0.1 * (1.0 + rainStrengthS) + horizon * (0.3 + 0.1 * sunVisibility);

    float meFactorP = min((1.0 - min(moonBrightness, 0.6) / 0.6) * 0.115, 0.075);
    float meNdotU = 1.0 - absNdotU;
    float meFactor = meFactorP * meNdotU * meNdotU * 15.0 * max(timeBrightnessInv4 - rainStrengthS, 0.0);
    vec3 meColor = mix(lightMorning, lightEvening, mefade);
    meColor *= meColor;
    meColor *= meColor;
    meColor *= meFactor * meFactor * NdotS;

    vec3 finalSky = mix(sky * (1.0 - pow2(lightmix)), lightCol * sqrt(lightCol), lightmix);

    vec3 nightSky = ambientNight * ambientNight * (3.25 + 2.25 * max(sqrt1(NdotU), 0.0));
    nightSky *= mix(SKY_NIGHT, 1.0, sunVisibility);
    #ifdef EIGHTHUNDREDTWENTYFOUR
        nightSky *= corbaWorldCol * 4.0;
    #endif
    #ifdef EIGHTHUNDREDTWENTYSEVEN
        nightSky *= purpleWorldCol * 4.0;
    #endif
    finalSky += nightSky;

    finalSky *= max(1.0 - length(meColor) * 0.5, 0.0);
    finalSky += meColor * 0.8;

    if (isReflection) {
        float invNdotU = max(-NdotU, 0.0);
        float groundFactor = 0.5 * (11.0 * rainStrengthS + 1.0) * (-5.0 * sunVisibility + 6.0);
        float ground = exp(-groundFactor / (invNdotU * 6.0));
        ground = smoothstep(0.0, 1.0, ground);
        mult *= (1.0 - ground);
    }

    //duplicate 98765
    vec3 weatherSky = weatherCol * weatherCol;
    weatherSky *= GetLuminance(ambientCol / (weatherSky)) * 1.4;
    weatherSky *= mix(SKY_RAIN_NIGHT, SKY_RAIN_DAY, sunVisibility);
    weatherSky = max(weatherSky, skyColor2 * 0.75); // Lightning Sky Color
    weatherSky *= rainStrengthS;
    finalSky = mix(finalSky, weatherSky, rainStrengthS) * mult;

    finalSky = pow(finalSky, vec3(1.125));

    #ifdef EIGHTHUNDREDTWENTY
        finalSky = mix(finalSky, finalSky * eucaWorldCol, 0.35);
    #endif

    #ifdef EIGHTHUNDREDTWENTYFOUR
        finalSky = mix(finalSky, finalSky * corbaWorldCol, 0.5);
    #endif

    #ifdef EIGHTHUNDREDTWENTYSEVEN
        finalSky = mix(finalSky, finalSky * purpleWorldCol, 0.5);
    #endif

    return finalSky;
}
