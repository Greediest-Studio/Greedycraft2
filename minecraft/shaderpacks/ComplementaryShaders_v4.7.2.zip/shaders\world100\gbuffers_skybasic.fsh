#version 130

#define ONEHUNDRED
#define GBUFFERS_SKYBASIC
#define FSH

#include "/program/gbuffers_skybasic.glsl"

