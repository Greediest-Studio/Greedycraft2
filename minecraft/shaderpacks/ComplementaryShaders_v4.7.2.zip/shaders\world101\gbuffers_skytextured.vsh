#version 130 

#define ONEHUNDREDONE
#define VSH

#define GBUFFERS_SKYTEXTURED

#include "/program/gbuffers_skytextured.glsl"

