#version 130

#define ONEHUNDREDTWO
#define GBUFFERS_SKYBASIC
#define FSH

#include "/program/gbuffers_skybasic.glsl"

