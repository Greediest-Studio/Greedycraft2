#version 130 

#define GBUFFERS_ENTITIES_GLOWING
#define ONEHUNDRED
#define VSH

#include "/program/gbuffers_entities.glsl"

