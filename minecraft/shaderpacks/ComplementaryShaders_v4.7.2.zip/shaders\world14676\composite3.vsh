#version 130 

#define SEVENTYEIGHT
#define DIM14676
#define VSH

#include "/program/composite3.glsl"

