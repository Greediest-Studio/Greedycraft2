#version 130 

#define GBUFFERS_ENTITIES
#define GBUFFERS_ENTITIES_GLOWING
#define ONEHUNDREDONE
#define FSH

#include "/program/gbuffers_entities.glsl"

