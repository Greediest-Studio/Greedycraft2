#version 130 

#define ONEHUNDREDTWO
#define VSH
#define GBUFFERS_LINE

#include "/program/gbuffers_basic.glsl"

