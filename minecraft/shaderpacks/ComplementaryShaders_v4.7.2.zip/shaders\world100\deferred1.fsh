#version 130 
#define OVERWORLD

#define DEFERRED
#define ONEHUNDRED
#define FSH

#include "/program/deferred1.glsl"

