#version 130 

#define ONEHUNDREDTWO
#define VSH

#define GBUFFERS_SKYTEXTURED

#include "/program/gbuffers_skytextured.glsl"

