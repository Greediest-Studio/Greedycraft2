// Dimension 824 corba world color overrides
// Includes after lightColor.glsl to provide euca-specific colors

// Corba world base color (used in fog, sky, reflections)
vec3 corbaWorldCol = vec3(0.133, 0.545, 0.133); // #228B22
