#version 130 

#define GBUFFERS_ENTITIES
#define GBUFFERS_ENTITIES_GLOWING
#define ONEHUNDREDTWO
#define FSH

#include "/program/gbuffers_entities.glsl"

