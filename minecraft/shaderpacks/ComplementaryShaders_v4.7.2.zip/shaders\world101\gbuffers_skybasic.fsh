#version 130

#define ONEHUNDREDONE
#define GBUFFERS_SKYBASIC
#define FSH

#include "/program/gbuffers_skybasic.glsl"

