#version 130 

#define ONEHUNDREDONE
#define FSH

#include "/program/gbuffers_armor_glint.glsl"

