/*
Complementary Shaders by EminGT, based on BSL Shaders by Capt Tatsu
*/

//Common//
#include "/lib/common.glsl"

//Varyings//
varying vec2 texCoord;

varying vec3 sunVec, upVec;

#ifdef COLORED_LIGHT
	varying vec3 lightAlbedo;
	varying	vec3 lightBuffer;
#endif

//////////Fragment Shader//////////Fragment Shader//////////Fragment Shader//////////
#ifdef FSH

//Uniforms//
uniform int frameCounter;
uniform int isEyeInWater;
uniform int worldDay;

uniform float isEyeInCave;
uniform float blindFactor, nightVision;
uniform float far, near;
uniform float frameTimeCounter;
uniform float rainStrengthS;
uniform float screenBrightness; 
uniform float viewWidth, viewHeight, aspectRatio;
uniform float eyeAltitude;

uniform ivec2 eyeBrightnessSmooth;

uniform vec3 skyColor;
uniform vec3 fogColor;

uniform mat4 gbufferProjection, gbufferPreviousProjection, gbufferProjectionInverse;
uniform mat4 gbufferModelView, gbufferPreviousModelView, gbufferModelViewInverse;
uniform mat4 shadowProjection;
uniform mat4 shadowModelView;

uniform sampler2D colortex0;
uniform sampler2D depthtex0;

#ifdef AO
	uniform sampler2D colortex4;
#endif

#ifdef AURORA
	uniform int moonPhase;
	#define UNIFORM_moonPhase
#endif

#if defined ADV_MAT || defined GLOWING_ENTITY_FIX || defined AO
	uniform sampler2D colortex3;
#endif

#if (defined ADV_MAT && defined REFLECTION_SPECULAR) || defined SEVEN || defined SEVENTYEIGHT || defined ONEHUNDRED || (defined END && defined ENDER_NEBULA) || (defined NETHER && defined NETHER_SMOKE)
	uniform vec3 cameraPosition;

	uniform sampler2D colortex6;
	uniform sampler2D colortex1;
	uniform sampler2D noisetex;
#endif

#ifdef AURORA
	uniform float isDry, isRainy, isSnowy;
#endif

//Optifine Constants//
#if defined ADV_MAT && defined REFLECTION_SPECULAR
	const bool colortex0MipmapEnabled = true;
#endif
#ifdef COLORED_LIGHT
	const bool colortex8MipmapEnabled = true;
#endif

//Common Variables//
float eBS = eyeBrightnessSmooth.y / 240.0;
float sunVisibility = clamp(dot( sunVec,upVec) + 0.0625, 0.0, 0.125) * 8.0;
float vsBrightness = clamp(screenBrightness, 0.0, 1.0);

vec3 lightVec = sunVec * (1.0 - 2.0 * float(timeAngle > 0.5325 && timeAngle < 0.9675));

vec2 aoOffsets[4] = vec2[4](
	vec2( 1.0,  0.0),
	vec2( 0.0,  1.0),
	vec2(-1.0,  0.0),
	vec2( 0.0, -1.0)
);

#if WORLD_TIME_ANIMATION == 2
	int modifiedWorldDay = int(mod(worldDay, 100.0) + 5.0);
	float frametime = (worldTime + modifiedWorldDay * 24000) * 0.05 * ANIMATION_SPEED;
	float cloudtime = frametime;
#endif
#if WORLD_TIME_ANIMATION == 1
	int modifiedWorldDay = int(mod(worldDay, 100.0) + 5.0);
	float frametime = frameTimeCounter * ANIMATION_SPEED;
	float cloudtime = (worldTime + modifiedWorldDay * 24000) * 0.05 * ANIMATION_SPEED;
#endif
#if WORLD_TIME_ANIMATION == 0
	float frametime = frameTimeCounter * ANIMATION_SPEED;
	float cloudtime = frametime;
#endif

#ifdef END
vec3 lightNight = vec3(0.0);
#endif

//Common Functions//
float GetLuminance(vec3 color) {
	return dot(color,vec3(0.299, 0.587, 0.114));
}

float GetNoise827(vec2 pos) {
	return fract(sin(dot(pos, vec2(12.9898, 4.1414))) * 43758.54953);
}

float ValueNoise827(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);

	float a = GetNoise827(i);
	float b = GetNoise827(i + vec2(1.0, 0.0));
	float c = GetNoise827(i + vec2(0.0, 1.0));
	float d = GetNoise827(i + vec2(1.0, 1.0));

	return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float FBM827(vec2 p) {
	float sum = 0.0;
	float amp = 0.55;
	for (int i = 0; i < 4; i++) {
		sum += ValueNoise827(p) * amp;
		p = p * 2.02 + vec2(13.7, 9.1);
		amp *= 0.5;
	}
	return sum;
}

vec3 DrawStars(inout vec3 color, vec3 viewPos, float NdotU);

#ifdef SEVENTYEIGHT
vec3 ForceSky78(vec3 nViewPos, vec3 viewPos) {
	vec3 worldDir78 = normalize((gbufferModelViewInverse * vec4(nViewPos, 0.0)).xyz);
	float worldUpDot78 = dot(worldDir78, vec3(0.0, 1.0, 0.0));
	float hemi78 = abs(worldUpDot78);
	float skyMix = clamp(hemi78 * 0.5 + 0.5, 0.0, 1.0);
	vec3 skyBottom = vec3(0.004, 0.010, 0.028);
	vec3 skyTop = vec3(0.001, 0.003, 0.012);
	vec3 sky = mix(skyBottom, skyTop, skyMix);
	sky += pow(1.0 - hemi78, 2.3) * vec3(0.008, 0.018, 0.050);

	vec3 domeCoord = 0.75 * worldDir78 / (abs(worldDir78.y) + length(worldDir78.xz) + 0.001);

	float skyField78 = pow(hemi78, 1.2);
	vec2 starCoord = floor(domeCoord.xz * 1024.0) / 1024.0;
	float star = 1.0;
	star *= GetNoise827(starCoord + vec2(0.13, 0.29));
	star *= GetNoise827(starCoord * 1.91 + vec2(0.47, 0.11));
	star *= GetNoise827(starCoord * 0.73 + vec2(0.05, 0.61));
	star = max(star - 0.83, 0.0);
	float twinkle = 0.75 + 0.25 * sin(frameTimeCounter * 1.6 + dot(starCoord, vec2(173.1, 91.7)) * 40.0);
	sky += vec3(0.85, 0.92, 1.08) * star * skyField78 * twinkle * 8.0;

	vec2 nebCoordA = domeCoord.xz * vec2(6.4, 5.2) + vec2(frameTimeCounter * 0.012, frameTimeCounter * 0.006);
	float nebBaseA = FBM827(nebCoordA + vec2(2.3, 6.7));
	float nebRidgeA = 1.0 - abs(nebBaseA * 2.0 - 1.0);
	float nebFineA = FBM827(nebCoordA * 3.6 + vec2(10.2, 4.1));
	float nebFilA = pow(max(nebRidgeA * 0.78 + nebFineA * 0.42 - 0.56, 0.0), 1.35);
	float nebMaskA = smoothstep(0.06, 0.74, nebFilA) * pow(hemi78, 0.55);
	vec3 nebColA = mix(vec3(0.20, 0.07, 0.03), vec3(0.98, 0.34, 0.10), nebFineA);
	sky += nebColA * nebMaskA * 1.15;

	vec2 nebCoordB = domeCoord.xz * vec2(11.0, 8.8) + vec2(-frameTimeCounter * 0.008, frameTimeCounter * 0.014);
	float nebBaseB = FBM827(nebCoordB + vec2(5.6, 1.9));
	float nebRidgeB = 1.0 - abs(nebBaseB * 2.0 - 1.0);
	float nebMaskB = smoothstep(0.30, 0.88, nebRidgeB) * pow(hemi78, 0.85);
	vec3 nebColB = mix(vec3(0.10, 0.04, 0.14), vec3(0.42, 0.12, 0.28), nebBaseB);
	sky += nebColB * nebMaskB * 0.42;

	return min(sky, vec3(3.0));
}
#endif

#ifdef DIM14676
vec3 ForceSky14676(vec3 nViewPos, vec3 viewPos) {
	vec3 sky14676 = vec3(0.0);
	float NdotU14676 = max(dot(nViewPos, upVec), 0.0);
	sky14676 += DrawStars(sky14676, viewPos, NdotU14676) * 0.32;
	return min(max(sky14676, vec3(0.0)), vec3(1.0));
}
#endif

#ifdef ONEHUNDRED
float Curve100(float x) {
	return x * x * (3.0 - 2.0 * x);
}

vec3 Blackbody100(float temperature) {
	const mat2x4 splineX = mat2x4(-0.2661293e9, -0.2343589e6, 0.8776956e3, 0.179910,
								  -3.0258469e9,  2.1070479e6, 0.2226347e3, 0.240390);

	const mat3x4 splineY = mat3x4(-1.1063814, -1.34811020, 2.18555832, -0.20219683,
								  -0.9549476, -1.37418593, 2.09137015, -0.16748867,
								   3.0817580, -5.87338670, 3.75112997, -0.37001483);

	float rt = 1.0 / temperature;
	float rt2 = rt * rt;
	vec4 coeffX = vec4(rt2 * rt, rt2, rt, 1.0);

	float x = dot(coeffX, temperature < 4000.0 ? splineX[0] : splineX[1]);
	float x2 = x * x;
	vec4 coeffY = vec4(x2 * x, x2, x, 1.0);

	float z = 1.0 / dot(coeffY, temperature < 2222.0 ? splineY[0] : temperature < 4000.0 ? splineY[1] : splineY[2]);

	vec3 xyz = vec3(x * z, 1.0, z);
	xyz.z -= xyz.x + 1.0;

	const mat3 xyzToSrgb = mat3( 3.24097, -0.96924,  0.05563,
								 -1.53738,  1.87597, -0.20398,
								 -0.49861,  0.04156,  1.05697);

	return max(xyzToSrgb * xyz, vec3(0.0));
}

mat3 RotateMatrix100(float x, float y, float z) {
	mat3 matx = mat3(1.0, 0.0, 0.0,
					 0.0, cos(x), sin(x),
					 0.0, -sin(x), cos(x));

	mat3 maty = mat3(cos(y), 0.0, -sin(y),
					 0.0, 1.0, 0.0,
					 sin(y), 0.0, cos(y));

	mat3 matz = mat3(cos(z), sin(z), 0.0,
					 -sin(z), cos(z), 0.0,
					 0.0, 0.0, 1.0);

	return maty * matx * matz;
}

void WarpSpace100(inout vec3 eyevec, inout vec3 raypos) {
	float singularityDist = length(raypos);
	float warpFactor = 1.0 / (singularityDist * singularityDist + 0.000001);
	vec3 singularityVector = normalize(-raypos);
	float warpAmount = 0.06;
	eyevec = normalize(eyevec + singularityVector * warpFactor * warpAmount);
}

float Calculate3DNoise100(vec3 position) {
	vec3 p = floor(position);
	vec3 b = vec3(Curve100(fract(position.x)), Curve100(fract(position.y)), Curve100(fract(position.z)));

	vec2 uv = 17.0 * p.z + p.xy + b.xy;
	vec2 rg = texture2DLod(noisetex, (uv + 0.5) / 64.0, 0.0).zx;

	return mix(rg.x, rg.y, b.z);
}

float CalculateCloudFBM100(vec3 position, vec3 shift) {
	const int octaves = 4;
	const float octAlpha = 0.87;
	const float octScale = 2.5;
	const float octShift = (octAlpha / octScale) / float(octaves);

	float accum = 0.0;
	float alpha = 0.5;

	for (int i = 0; i < octaves; i++) {
		accum += alpha * Calculate3DNoise100(position);
		position = (position + shift) * octScale;
		alpha *= octAlpha;
	}

	return accum + octShift;
}

float pcurve100(float x) {
	float x2 = x * x;
	return 12.207 * x2 * x2 * (1.0 - x);
}

void BlackHole_AccretionDisc_Stars100(inout vec3 color, in vec3 rayDirIn, in vec3 lightDir) {
	const float steps = 50.0;
	const float rSteps = 1.0 / steps;
	const float stepLength = 0.2;

	const float discRadius = 2.25;
	const float discWidth = 5.6;
	const float discInner = discRadius - discWidth * 0.5;

	float noise = GetNoise827(gl_FragCoord.xy);

	vec3 rayDir = rayDirIn;
	vec3 eye = -lightDir * 4.8;
	vec3 rayPos = eye + rayDir * 1.6;

	mat3 rotation = RotateMatrix100(0.1, 0.0, -0.35);

	vec3 result = vec3(0.0);
	float transmittance = 1.0;
	vec3 nearFieldAccum = vec3(0.0);

	// Analytic near-field support sampled from disc plane intersection.
	// This prevents camera-proximate gaps when ray-march density drops locally.
	vec3 roDisc = rotation * eye;
	vec3 rdDisc = rotation * rayDir;
	float rdY = rdDisc.y;
	if (abs(rdY) > 0.0001) {
		float tPlane = -roDisc.y / rdY;
		if (tPlane > 0.0 && tPlane < 8.0) {
			vec3 hitDisc = roDisc + rdDisc * tPlane;
			float rPlane = length(hitDisc);
			float radialPlane = 1.0 - clamp((rPlane - discInner) / discWidth * 0.5, 0.0, 1.0);
			float bandPlane = pcurve100(radialPlane);
			float nearGain = 1.0 - smoothstep(2.0, 8.0, tPlane);
			float planeDensity = bandPlane * nearGain;
			float planeNoise = CalculateCloudFBM100(vec3(rPlane, 0.0, 0.0) * 2.8, frameTimeCounter * vec3(0.02, 0.03, 0.0));
			vec3 planeGlow = Blackbody100(3000.0 + 900.0 * planeDensity);
			nearFieldAccum += planeGlow * (0.26 + 0.74 * planeNoise) * planeDensity * 0.42;
		}
	}

	rayPos += rayDir * stepLength * noise;

	for (int i = 0; i < 50; i++) {
		if (transmittance < 0.0001) break;

		WarpSpace100(rayDir, rayPos);
		rayPos += rayDir * stepLength;

		vec3 discPos = rotation * rayPos;

		float r = length(discPos);
		float p = atan(-discPos.z, discPos.x);
		float h = discPos.y;

		float radialGradient = 1.0 - clamp((r - discInner) / discWidth * 0.5, 0.0, 1.0);
		float dist = abs(h);
		float discThickness = 0.26 * radialGradient;

		float fr = abs(r - discInner) + 0.4;
		fr = fr * fr;
		float fade = fr * fr * 0.04;
		float bloomFactor = 1.0 / (h * h * 180.0 + fade * 2.6 + 0.00002);
		bloomFactor *= clamp(2.0 - abs(dist) / max(discThickness, 1e-5), 0.0, 1.0);
		bloomFactor *= bloomFactor;

		float dr = pcurve100(radialGradient);
		float density = dr;
		density *= clamp(1.0 - abs(dist) / max(discThickness, 1e-5), 0.0, 1.0);
		density = clamp(density * 1.30, 0.0, 1.0);
		density = clamp(density + bloomFactor * 0.16, 0.0, 1.0);

		if (density > 0.0001) {
			vec3 discCoord = vec3(r, 0.0, h * 0.1) * 3.5;
			float fbm = CalculateCloudFBM100(discCoord, frameTimeCounter * vec3(0.03, 0.05, 0.0));
			fbm *= fbm;

			density *= (0.45 + 0.55 * fbm) * dr;

			float gr = 1.0 - radialGradient;
			gr *= gr;
			float glowStrength = 1.0 / (gr * gr * 170.0 + 0.0012);
			vec3 glow = Blackbody100(2700.0 + glowStrength * 50.0) * glowStrength;
			glow *= sin(p - 1.07) * 0.75 + 1.0;
			glow *= 1.85;

			float stepTransmittance = exp2(-density * 3.9);
			float integral = 1.0 - stepTransmittance;
			transmittance *= stepTransmittance;

			result += integral * transmittance * glow;

			// Keep disc continuity in close range: add a stable near-field floor layer
			// so camera-proximate segments do not collapse into voids.
			float travel = float(i) * stepLength;
			float nearMask = 1.0 - smoothstep(0.8, 4.4, travel);
			float nearDiscMask = clamp(1.0 - abs(dist) / (discThickness * 1.8 + 1e-5), 0.0, 1.0);
			float nearRadial = clamp(radialGradient, 0.0, 1.0);
			float nearDensity = nearMask * nearDiscMask * nearRadial;
			nearDensity *= 0.32 + 0.68 * fbm;
			nearFieldAccum += glow * nearDensity * 0.070;
		}

		// Tight white event-horizon ring, removing the previous broad blue halo.
		float ringDist = abs(r - 0.84);
		float ringMask = exp2(-ringDist * ringDist * 900.0);
		ringMask *= exp2(-h * h * 520.0);
		vec3 ringCol = vec3(1.55, 1.52, 1.46);
		result += ringCol * ringMask * 0.30 * transmittance;
	}

	result *= rSteps;
	result *= 1.90;
	nearFieldAccum *= rSteps * 2.00;
	color *= transmittance;
	color += result + nearFieldAccum;
}

vec3 ForceSky100(vec3 nViewPos) {
	vec3 worldDir100 = normalize((gbufferModelViewInverse * vec4(nViewPos, 0.0)).xyz);
	vec3 sky100 = vec3(0.0);

	// Fixed near-horizon black hole direction (centered on horizon instead of following sun).
	vec3 worldLightDir100 = normalize(vec3(0.0, -0.14, 1.0));
	BlackHole_AccretionDisc_Stars100(sky100, worldDir100, worldLightDir100);

	// Transparent core: clear center emission so the black hole interior blends into pure black sky.
	float centerDot100 = dot(worldDir100, worldLightDir100);
	float coreTransparent100 = smoothstep(0.920, 0.980, centerDot100);
	sky100 = mix(sky100, vec3(0.0), coreTransparent100);

	return min(max(sky100, vec3(0.0)), vec3(1.6));
}
#endif

#ifdef ONEHUNDREDONE
vec3 ForceSky101(vec3 nViewPos) {
	vec3 worldDir101 = normalize((gbufferModelViewInverse * vec4(nViewPos, 0.0)).xyz);
	float hemi101 = clamp(worldDir101.y * 0.5 + 0.5, 0.0, 1.0);
	float grad101 = pow(hemi101, 1.18);

	// Deep-purple sky gradient.
	vec3 skyHorizon101 = vec3(0.060, 0.032, 0.086);
	vec3 skyZenith101 = vec3(0.013, 0.007, 0.026);
	vec3 sky101 = mix(skyHorizon101, skyZenith101, grad101);

	// Very subtle texture for depth.
	vec2 skyUV101 = vec2(atan(worldDir101.z, worldDir101.x), asin(clamp(worldDir101.y, -1.0, 1.0)));
	float grain101 = FBM827(skyUV101 * vec2(2.5, 1.9) + vec2(4.4, 1.7));
	sky101 += vec3(0.0032, 0.0019, 0.0048) * (grain101 - 0.5);

	return min(max(sky101, vec3(0.0)), vec3(1.6));
}
#endif

#ifdef ONEHUNDREDTWO
vec3 ChainArcProfile102(vec3 worldDir, vec3 horizonDir, float phaseShift) {
	vec3 upDir = vec3(0.0, 1.0, 0.0);
	vec3 planeNormal = normalize(cross(upDir, horizonDir));

	float upperMask = smoothstep(-0.04, 0.02, worldDir.y);
	float t = atan(max(worldDir.y, 0.0), dot(worldDir, horizonDir));
	float tNorm = clamp(t / 3.14159265, 0.0, 1.0);

	float linkCount = 42.0;
	float seg = floor(tNorm * linkCount + phaseShift);
	float parity = mod(seg, 2.0) * 2.0 - 1.0;
	float strandOffset = parity * 0.0090;
	float radial = abs(dot(worldDir, planeNormal) - strandOffset);

	float width = mix(0.0145, 0.0070, clamp(worldDir.y, 0.0, 1.0));
	float body = 1.0 - smoothstep(width, width * 1.70, radial);

	float radialNorm = clamp(radial / max(width, 0.0001), 0.0, 1.0);
	float roundSection = pow(max(1.0 - radialNorm * radialNorm, 0.0), 0.58);

	float linkPhase = fract(tNorm * linkCount + phaseShift * 0.031);
	float linkRound = 1.0 - abs(linkPhase * 2.0 - 1.0);
	linkRound = smoothstep(0.18, 0.98, linkRound);

	float mask = body * upperMask * mix(0.80, 1.15, linkRound);
	float spec = pow(clamp(roundSection * (0.45 + 0.55 * linkRound), 0.0, 1.0), 5.5) * mask;
	float outlineBand = smoothstep(0.58, 0.82, radialNorm) * (1.0 - smoothstep(0.82, 1.10, radialNorm));
	float outline = outlineBand * upperMask * mix(0.85, 1.10, linkRound);

	return vec3(mask, spec, outline);
}

vec3 ForceSky102(vec3 nViewPos) {
	vec3 worldDir102 = normalize((gbufferModelViewInverse * vec4(nViewPos, 0.0)).xyz);
	float hemi102 = clamp(worldDir102.y * 0.5 + 0.5, 0.0, 1.0);
	float grad102 = pow(hemi102, 1.12);

	vec3 skyHorizon102 = vec3(0.33, 0.34, 0.35);
	vec3 skyZenith102 = vec3(0.47, 0.48, 0.49);
	vec3 sky102 = mix(skyHorizon102, skyZenith102, grad102);

	vec2 skyUV102 = vec2(atan(worldDir102.z, worldDir102.x), asin(clamp(worldDir102.y, -1.0, 1.0)));
	float grain102 = FBM827(skyUV102 * vec2(2.9, 2.1) + vec2(1.7, 5.2));
	sky102 += vec3(0.0035, 0.0035, 0.0035) * (grain102 - 0.5);

	vec3 hA = normalize(vec3(1.0, 0.0, 0.0));
	vec3 hB = normalize(vec3(0.0, 0.0, 1.0));
	vec3 chainA = ChainArcProfile102(worldDir102, hA, 0.0);
	vec3 chainB = ChainArcProfile102(worldDir102, hB, 21.0);
	float chainMask = max(chainA.x, chainB.x);
	float chainSpec = max(chainA.y, chainB.y);
	float chainOutline = max(chainA.z, chainB.z);

	float zenithJoint = smoothstep(0.948, 0.995, worldDir102.y) * (chainA.x + chainB.x);
	vec3 goldDark = vec3(0.52, 0.40, 0.10);
	vec3 goldMid = vec3(0.88, 0.70, 0.20);
	vec3 goldHigh = vec3(1.28, 1.02, 0.36);
	vec3 goldOutline = vec3(0.24, 0.17, 0.03);
	vec3 goldCol = mix(goldDark, goldMid, clamp(chainMask * 0.9 + zenithJoint * 0.25, 0.0, 1.0));
	goldCol += goldHigh * (chainSpec * 0.72 + zenithJoint * 0.18);
	sky102 = mix(sky102, goldOutline, clamp(chainOutline * 0.95 + zenithJoint * 0.10, 0.0, 1.0));
	sky102 = mix(sky102, goldCol, clamp(chainMask * 0.98 + chainSpec * 0.45 + zenithJoint * 0.28, 0.0, 1.0));

	return min(max(sky102, vec3(0.0)), vec3(1.6));
}
#endif

float GetLinearDepth(float depth) {
   return (2.0 * near) / (far + near - depth * (far - near));
}

#ifdef AO
    vec2 OffsetDist(float x, int s) {
        float n = fract(x * 1.414) * 3.1415;
        return pow2(vec2(cos(n), sin(n)) * x / s);
    }

    float DoAmbientOcclusion(float linearZ0, float dither) {
        float ao = 0.0;

		#if AA > 1
			int samples = 12 * AO_QUALITY;

			float ditherAnimate = 1.61803398875 * mod(float(frameCounter), 3600.0);
			dither = fract(dither + ditherAnimate);
		#else
			int samples = 24 * AO_QUALITY;
		#endif
			
		float farMinusNear = far - near;
        
        float sampleDepth = 0.0, angle = 0.0, dist = 0.0;
        float fovScale = gbufferProjection[1][1] / 1.37;
        float distScale = max(farMinusNear * linearZ0 + near, 3.0);
        vec2 scale = vec2(0.4 / aspectRatio, 0.5) * fovScale / distScale;

        for (int i = 1; i <= samples; i++) {
            vec2 offset = OffsetDist(i + dither, samples) * scale;
            if (i % 2 == 0) offset.y = -offset.y;

            vec2 coord1 = texCoord + offset;
            vec2 coord2 = texCoord - offset;

            sampleDepth = GetLinearDepth(texture2D(depthtex0, coord1).r);
            float aosample = farMinusNear * (linearZ0 - sampleDepth) * 2.0;
            angle = clamp(0.5 - aosample, 0.0, 1.0);
            dist = clamp(0.5 * aosample - 1.0, 0.0, 1.0);

            sampleDepth = GetLinearDepth(texture2D(depthtex0, coord2).r);
            aosample = farMinusNear * (linearZ0 - sampleDepth) * 2.0;
            angle += clamp(0.5 - aosample, 0.0, 1.0);
            dist += clamp(0.5 * aosample - 1.0, 0.0, 1.0);
            
            ao += clamp(angle + dist, 0.0, 1.0);
        }
        ao /= samples;
        
        return pow(ao, AO_STRENGTH_NEW);
    }
#endif

#if SELECTION_MODE == 2 && defined ADV_MAT
vec3 GetVersatileOutline(vec3 color) {
	vec3 colorSqrt = sqrt(color.rgb);
	float perceived = 0.1126 * colorSqrt.r + 0.4152 * colorSqrt.g + 0.2722 * colorSqrt.b;

	color.rgb = color.rgb + max(normalize(color.rgb) * max(perceived * perceived, 0.001), vec3(0.0));
	color.rgb *= 20.0;

	perceived = max(1.0 - perceived * 1.3, 0.0);
	perceived *= perceived;
	perceived *= perceived;
	perceived = min(perceived, 1.0);
	float perSteep = 16.0;
	if (perceived > 0.5) perceived = pow((perceived - 0.5) * 2.0, 1.0 / perSteep) * 0.5 + 0.5;
	else perceived = pow(perceived * 2.0, perSteep) * 0.5;
	color.rgb *= max(perceived * 0.5, 0.007);
	return color.rgb;
}
#endif

//Includes//
#include "/lib/color/dimensionColor.glsl"
#include "/lib/color/skyColor.glsl"
#include "/lib/color/blocklightColor.glsl"
#include "/lib/color/waterColor.glsl"
#include "/lib/util/dither.glsl"
#include "/lib/util/spaceConversion.glsl"

	#ifdef OVERWORLD
	#include "/lib/atmospherics/sky.glsl"
	#endif
#if defined SEVEN || defined SEVENTYEIGHT || (defined ADV_MAT && defined REFLECTION_SPECULAR && defined OVERWORLD) || (defined END && defined ENDER_NEBULA) || (defined NETHER && defined NETHER_SMOKE) || defined EIGHTHUNDREDTWENTYTWO || defined EIGHTHUNDREDTWENTYSEVEN
	#ifdef AURORA
		#include "/lib/color/auroraColor.glsl"
	#endif
	#include "/lib/atmospherics/skyboxEffects.glsl"
#endif

#include "/lib/atmospherics/fog.glsl"

#ifdef BLACK_OUTLINE
	#include "/lib/outline/blackOutline.glsl"
#endif

#ifdef PROMO_OUTLINE
	#include "/lib/outline/promoOutline.glsl"
#endif

#if defined ADV_MAT && defined REFLECTION_SPECULAR
	#include "/lib/util/encode.glsl"
	#include "/lib/reflections/raytrace.glsl"
	#include "/lib/reflections/complexFresnel.glsl"
	#include "/lib/surface/materialDeferred.glsl"
	#include "/lib/reflections/roughReflections.glsl"
#endif

//Program//
void main() {
    vec4 color = texture2D(colortex0, texCoord);
	float z    = texture2D(depthtex0, texCoord).r;

	float dither = Bayer64(gl_FragCoord.xy);
	
	vec4 screenPos = vec4(texCoord, z, 1.0);
	vec4 viewPos = gbufferProjectionInverse * (screenPos * 2.0 - 1.0);
	viewPos /= viewPos.w;

	#if defined NETHER && defined NETHER_SMOKE
		vec3 netherSmoke = DrawNetherSmoke(viewPos.xyz, dither, pow((netherCol * 2.5) / NETHER_I, vec3(2.2)) * 4);
	#endif
	#if defined EIGHTHUNDREDTWENTYTWO && defined NETHER_SMOKE
		vec3 netherSmoke = DrawNetherSmoke(viewPos.xyz, dither, lavaWorldCol * 2.5);
	#endif
	#if defined END && defined ENDER_NEBULA
		vec3 nebulaStars = vec3(0.0);
		vec3 enderNebula = DrawEnderNebula(viewPos.xyz, dither, endCol, nebulaStars);
		nebulaStars = pow(nebulaStars, vec3(1.0 / 2.2));
		nebulaStars *= pow(nebulaStars, vec3(2.2));
		enderNebula = pow(enderNebula, vec3(1.0 / 2.2));
		enderNebula *= pow(enderNebula, vec3(2.2));
	#endif

	if (z < 1.0) {
		#if defined ADV_MAT || defined GLOWING_ENTITY_FIX || defined AO
			float skymapMod = texture2D(colortex3, texCoord).b;
			// skymapMod = 1.0            = Glowing Status Effect
			// skymapMod = 0.995          = Versatile Selection Outline
			// skymapMod = 0.515 ... 0.99 = Cauldron
			// skymapMod = 0.51           = No SSAO
			// skymapMod = 0.0   ... 0.5  = Rain Puddles
			// skymapMod = 0.0   ... 0.1  = Specular Sky Reflections
		#endif

		vec3 nViewPos = normalize(viewPos.xyz);
		float NdotU = dot(nViewPos, upVec);
		float lViewPos = length(viewPos.xyz);
		vec3 worldPos = ViewToWorld(viewPos.xyz);
	
		#ifdef AO
			float ao = clamp(DoAmbientOcclusion(GetLinearDepth(z), dither), 0.0, 1.0);
			float ambientOcclusion = ao;
		#endif

		#if SELECTION_MODE == 2 && defined ADV_MAT
			if (skymapMod > 0.9925 && 0.9975 > skymapMod) {
				color.rgb = GetVersatileOutline(color.rgb);
			}
		#endif

		#if defined ADV_MAT && defined REFLECTION_SPECULAR
			float smoothness = 0.0, metalness = 0.0, f0 = 0.0;
			vec3 normal = vec3(0.0), rawAlbedo = vec3(0.0);

			GetMaterials(smoothness, metalness, f0, normal, rawAlbedo, texCoord);

			float smoothnessP = smoothness;
			smoothness *= smoothness;
			
			float fresnel = pow(clamp(1.0 + dot(normal, nViewPos), 0.0, 1.0), 5.0);
			vec3 fresnel3 = vec3(0.0);

			rawAlbedo *= 5.0;
			float fresnelFactor = 0.25;

			#ifdef COMPBR
				if (f0 > 1.1) {
					fresnel = fresnel * 0.8 + 0.2;
					fresnelFactor *= 1.5;
				}
				fresnel3 = mix(mix(vec3(0.02), rawAlbedo, metalness), vec3(1.0), fresnel);
				if (metalness <= 0.004 && metalness > 0.0 && skymapMod == 0.0) fresnel3 = vec3(0.0);
				fresnel3 *= fresnelFactor * smoothness;
			#else
				#if RP_SUPPORT == 4
					fresnel3 = mix(mix(vec3(0.02), rawAlbedo, metalness), vec3(1.0), fresnel);
					fresnel3 *= fresnelFactor * smoothness;
				#endif
				#if RP_SUPPORT == 3
					fresnel3 = mix(mix(vec3(max(f0, 0.02)), rawAlbedo, metalness), vec3(1.0), fresnel);
					if (f0 >= 0.9 && f0 < 1.0) {
						fresnel3 = ComplexFresnel(fresnel, f0) * 1.5;
						color.rgb *= 1.5;
					}
					fresnel3 *= fresnelFactor * smoothness;
				#endif
			#endif

			float lFresnel3 = length(fresnel3);
			if (lFresnel3 < 0.0050) fresnel3 *= (lFresnel3 - 0.0025) / 0.0025;

			if (lFresnel3 > 0.0025) {
				vec4 reflection = vec4(0.0);
				vec3 skyReflection = vec3(0.0);

				#ifdef REFLECTION_ROUGH
					float roughness = 1.0 - smoothnessP;
					#ifdef COMPBR
						roughness *= 1.0 - 0.35 * float(metalness == 1.0);
					#endif
					roughness *= roughness;

					vec3 roughPos = worldPos + cameraPosition;
					roughPos *= 1000.0;
					vec3 roughNoise = texture2D(noisetex, roughPos.xz + roughPos.y).rgb;
					roughNoise = 0.3 * (roughNoise - vec3(0.5));
					
					roughNoise *= roughness;

					normal += roughNoise;
					reflection = RoughReflection(viewPos.xyz, normal, dither, smoothness);

					#ifdef DOUBLE_QUALITY_ROUGH_REF
						vec3 altRoughNormal = normal - roughNoise*2;
						reflection += RoughReflection(viewPos.xyz, altRoughNormal, dither, smoothness);
						reflection /= 2.0;
					#endif
				#else
					reflection = RoughReflection(viewPos.xyz, normal, dither, smoothness);
				#endif

				float cauldron = float(skymapMod > 0.51 && skymapMod < 0.9905);
				if (cauldron > 0.5) { 													//Cauldron Reflections
					#ifdef OVERWORLD
						fresnel3 = fresnel3 * 3.33333333 + vec3(0.0333333);

						float skymapModM = (skymapMod - 0.515) / 0.475;
						#if SKY_REF_FIX_1 == 1
							skymapModM = skymapModM * skymapModM;
						#elif SKY_REF_FIX_1 == 2
							skymapModM = max(skymapModM - 0.80, 0.0) * 5.0;
						#else
							skymapModM = max(skymapModM - 0.99, 0.0) * 100.0;
						#endif
						skymapModM = skymapModM * 0.5;

						vec3 skyReflectionPos = reflect(nViewPos, normal);
						float refNdotU = dot(skyReflectionPos, upVec);
						skyReflection = GetSkyColor(lightCol, refNdotU, skyReflectionPos, true);
						skyReflectionPos *= 1000000.0;

						#ifdef AURORA
							skyReflection += DrawAurora(skyReflectionPos, dither, 8, refNdotU);
						#endif
						#ifdef CLOUDS
							vec4 cloud = DrawCloud(skyReflectionPos, dither, lightCol, ambientCol, refNdotU, 3);
							float cloudMixRate = smoothness * smoothness * (3.0 - 2.0 * smoothness);
							skyReflection = mix(skyReflection, cloud.rgb, cloud.a * cloudMixRate);
						#endif
						skyReflection = mix(vec3(0.001), skyReflection, skymapModM * 2.0);
					#endif
					#ifdef NETHER
						skyReflection = netherCol * 0.005;
					#endif
					#ifdef END
						float skymapModM = (skymapMod - 0.515) / 0.475;
						skyReflection = endCol * 0.025;
						#ifdef ENDER_NEBULA
							vec3 skyReflectionPos = reflect(nViewPos, normal);
							skyReflectionPos *= 1000000.0;
							vec3 nebulaStars = vec3(0.0);
							vec3 nebulaCRef = DrawEnderNebula(skyReflectionPos, dither, endCol, nebulaStars);
							nebulaCRef += nebulaStars;
							skyReflection = nebulaCRef;
						#endif
						skyReflection *= 5.0 * skymapModM;
					#endif
				}
				if (skymapMod > 0.0 && skymapMod < 0.505) {
					#ifdef OVERWORLD												 //Rain Puddle + Specular Sky Reflections
						float skymapModM = skymapMod * 2.0;

						vec3 skyReflectionPos = reflect(nViewPos, normal);
						float refNdotU = dot(skyReflectionPos, upVec);
						skyReflection = GetSkyColor(lightCol, refNdotU, skyReflectionPos, true);
						skyReflectionPos *= 1000000.0;

						#ifdef CLOUDS
							vec4 cloud = DrawCloud(skyReflectionPos, dither, lightCol, ambientCol, refNdotU, 3);
							float cloudMixRate = smoothness * smoothness * (3.0 - 2.0 * smoothness);
							skyReflection = mix(skyReflection, cloud.rgb, cloud.a * cloudMixRate);
						#endif
						skyReflection = mix(vec3(0.001), skyReflection * 5.0, skymapModM);
					#endif
					#if defined END	&& defined ENDER_NEBULA	  							//End Ground Reflections
						vec3 skyReflectionPos = reflect(nViewPos, normal);
						skyReflectionPos *= 1000000.0;
						vec3 nebulaStars = vec3(0.0);
						vec3 nebulaGRef = DrawEnderNebula(skyReflectionPos, dither, endCol, nebulaStars);
						nebulaGRef += nebulaStars;
						skyReflection = nebulaGRef;
					#endif
				}

				reflection.rgb = max(mix(skyReflection, reflection.rgb, reflection.a), vec3(0.0));
				
				#ifdef AO
					if (skymapMod < 0.505) reflection.rgb *= pow(min(ao + max(0.25 - lViewPos * 0.01, 0.0), 1.0), min(lViewPos * 0.75, 10.0));
				#endif
				
				color.rgb = color.rgb * (1.0 - fresnel3 * (1.0 - metalness)) +
							reflection.rgb * fresnel3;

				#ifdef SHOW_RAY_TRACING
					float timeThing1 = abs(fract(frameTimeCounter * 1.35) - 0.5) * 2.0;
					float timeThing2 = abs(fract(frameTimeCounter * 1.15) - 0.5) * 2.0;
					float timeThing3 = abs(fract(frameTimeCounter * 1.55) - 0.5) * 2.0;
					color.rgb = 3.0 * pow(vec3(timeThing1, timeThing2, timeThing3), vec3(3.2));
				#endif
			}
		#endif
		
		#ifdef GLOWING_ENTITY_FIX
			if (skymapMod > 0.9975) {
				vec2 glowOutlineOffsets[8] = vec2[8](
									vec2(-1.0, 0.0),
									vec2( 0.0, 1.0),
									vec2( 1.0, 0.0),
									vec2( 0.0,-1.0),
									vec2(-1.0,-1.0),
									vec2(-1.0, 1.0),
									vec2( 1.0,-1.0),
									vec2( 1.0, 1.0)
									);

				float outline = 0.0;

				for(int i = 0; i < 64; i++) {
					vec2 offset = vec2(0.0);
					offset = glowOutlineOffsets[i-8*int(i/8)] * 0.00025 * (int(i/8)+1);
					outline += clamp(1.0 - texture2D(colortex3, texCoord + offset).b, 0.0, 1.0);
				}
				
				color.rgb += outline * vec3(0.05);
			}
		#endif
		
		#ifdef AO
			if (skymapMod < 0.505)
			color.rgb *= ambientOcclusion;
		#endif
		
		#ifdef PROMO_OUTLINE
			PromoOutline(color.rgb, depthtex0);
		#endif

		vec3 extra = vec3(0.0);
		#if defined NETHER && defined NETHER_SMOKE
			extra = netherSmoke;
		#endif
		#if defined EIGHTHUNDREDTWENTYTWO && defined NETHER_SMOKE
			extra = netherSmoke;
		#endif
		#if defined END && defined ENDER_NEBULA
			extra = enderNebula;
		#endif

		color.rgb = startFog(color.rgb, nViewPos, lViewPos, worldPos, extra, NdotU);

		#ifdef ONEHUNDREDONE
			float purpleFog101 = smoothstep(24.0, 180.0, lViewPos);
			purpleFog101 *= 0.11;
			color.rgb = mix(color.rgb, vec3(0.155, 0.090, 0.220), purpleFog101);
		#endif

	
	} else { /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/ /**/
		float NdotU = 0.0;

		vec2 skyBlurOffset[4] = vec2[4](vec2( 0.0,  1.0),
										vec2( 0.0, -1.0),
										vec2( 1.0,  0.0),
										vec2(-1.0,  0.0));
		vec2 wh = vec2(viewWidth, viewHeight);
		vec3 skyBlurColor = color.rgb;
		for(int i = 0; i < 4; i++) {
			vec2 texCoordM = texCoord + skyBlurOffset[i] / wh;
			float depth = texture2D(depthtex0, texCoordM).r;
			if (depth == 1.0) skyBlurColor += texture2DLod(colortex0, texCoordM, 0).rgb;
			else skyBlurColor += color.rgb;
		}
		color.rgb = skyBlurColor / 5.0;

		#ifdef NETHER
			color.rgb = pow((netherCol * 2.5) / NETHER_I, vec3(2.2)) * 4;
			#ifdef NETHER_SMOKE
				color.rgb += netherSmoke;
			#endif
		#endif

		#ifdef EIGHTHUNDREDTWENTYTWO
			NdotU = max(dot(normalize(viewPos.xyz), upVec), 0.0);
			color.rgb = lavaWorldCol * 0.12 * (0.4 + 0.6 * NdotU);
			color.rgb += DrawTwoSuns(viewPos.xyz);
			color.rgb += DrawStars(color.rgb, viewPos.xyz, NdotU);
			#ifdef NETHER_SMOKE
				color.rgb += netherSmoke;
			#endif
		#endif

		#ifdef SEVENTYEIGHT
			vec4 skyScreenPos78 = vec4(texCoord, 1.0, 1.0);
			vec4 skyViewPos78 = gbufferProjectionInverse * (skyScreenPos78 * 2.0 - 1.0);
			skyViewPos78 /= skyViewPos78.w;
			vec3 skyViewDir78 = normalize(skyViewPos78.xyz);
			color.rgb = ForceSky78(skyViewDir78, skyViewPos78.xyz);
			#ifdef ENDER_NEBULA
				vec3 nebulaStars78 = vec3(0.0);
				vec3 enderNebula78 = DrawEnderNebula(skyViewPos78.xyz, dither, vec3(0.95, 0.38, 0.10), nebulaStars78);
				nebulaStars78 = pow(nebulaStars78, vec3(1.0 / 2.2));
				nebulaStars78 *= pow(nebulaStars78, vec3(2.2));
				enderNebula78 = pow(enderNebula78, vec3(1.0 / 2.2));
				enderNebula78 *= pow(enderNebula78, vec3(2.2));
				color.rgb += (enderNebula78 + nebulaStars78) * 0.55;
			#endif
		#endif

		#ifdef DIM14676
			vec4 skyScreenPos14676 = vec4(texCoord, 1.0, 1.0);
			vec4 skyViewPos14676 = gbufferProjectionInverse * (skyScreenPos14676 * 2.0 - 1.0);
			skyViewPos14676 /= skyViewPos14676.w;
			vec3 skyViewDir14676 = normalize(skyViewPos14676.xyz);
			color.rgb = ForceSky14676(skyViewDir14676, skyViewPos14676.xyz);
		#endif

		#ifdef ONEHUNDRED
			vec4 skyScreenPos100 = vec4(texCoord, 1.0, 1.0);
			vec4 skyViewPos100 = gbufferProjectionInverse * (skyScreenPos100 * 2.0 - 1.0);
			skyViewPos100 /= skyViewPos100.w;
			vec3 skyViewDir100 = normalize(skyViewPos100.xyz);
			color.rgb = ForceSky100(skyViewDir100);
		#endif

		#ifdef ONEHUNDREDONE
			vec4 skyScreenPos101 = vec4(texCoord, 1.0, 1.0);
			vec4 skyViewPos101 = gbufferProjectionInverse * (skyScreenPos101 * 2.0 - 1.0);
			skyViewPos101 /= skyViewPos101.w;
			vec3 skyViewDir101 = normalize(skyViewPos101.xyz);
			color.rgb = ForceSky101(skyViewDir101);
		#endif

		#ifdef ONEHUNDREDTWO
			vec4 skyScreenPos102 = vec4(texCoord, 1.0, 1.0);
			vec4 skyViewPos102 = gbufferProjectionInverse * (skyScreenPos102 * 2.0 - 1.0);
			skyViewPos102 /= skyViewPos102.w;
			vec3 skyViewDir102 = normalize(skyViewPos102.xyz);
			color.rgb = ForceSky102(skyViewDir102);
		#endif

		#ifdef EIGHTHUNDREDTWENTYSIX
			vec3 nViewPos826 = normalize(viewPos.xyz);
			float celestialDot826 = abs(dot(nViewPos826, sunVec));
			float celestialDisk826 = smoothstep(0.99910, 0.99972, celestialDot826);
			float celestialRing826 = smoothstep(0.99780, 0.99910, celestialDot826) - celestialDisk826;
			float celestialOutline826 = smoothstep(0.99690, 0.99795, celestialDot826) - smoothstep(0.99795, 0.99910, celestialDot826);
			color.rgb = vec3(1.0);
			color.rgb = mix(color.rgb, vec3(0.82), max(celestialOutline826, 0.0) * 0.85);
			color.rgb += vec3(0.11) * celestialDisk826;
			color.rgb += vec3(0.05) * max(celestialRing826, 0.0);
		#endif

		#ifdef FOURHUNDREDTWENTYFIVE
			vec3 nViewPos425 = normalize(viewPos.xyz);
			float skyMix425 = clamp(dot(nViewPos425, upVec) * 0.5 + 0.5, 0.0, 1.0);
			vec3 skyBottom425 = vec3(0.010, 0.018, 0.035);
			vec3 skyTop425 = vec3(0.030, 0.055, 0.105);
			color.rgb = mix(skyBottom425, skyTop425, skyMix425);

			vec3 wpos425 = vec3(gbufferModelViewInverse * vec4(viewPos.xyz, 1.0));
			vec3 planeCoord425 = 0.75 * wpos425 / (wpos425.y + length(wpos425.xz));
			vec2 starCoord425 = floor(planeCoord425.xz * 0.5 * 1024.0) / 1024.0;
			float star425 = 1.0;
			if (dot(nViewPos425, upVec) > 0.0) {
				star425 *= GetNoise827(starCoord425);
				star425 *= GetNoise827(starCoord425 + 0.1);
				star425 *= GetNoise827(starCoord425 + 0.23);
			}
			star425 = max(star425 - 0.80, 0.0);
			float starMult425 = 6.8 * pow(max(dot(nViewPos425, upVec), 0.0), 1.9);
			color.rgb += vec3(0.70, 0.80, 1.00) * star425 * starMult425;

			float moonDot425 = dot(nViewPos425, -sunVec);
			float moonDisk425 = smoothstep(0.99912, 0.99970, moonDot425);
			float moonRing425 = smoothstep(0.9978, 0.99912, moonDot425) - moonDisk425;
			color.rgb += vec3(0.78, 0.84, 0.95) * moonDisk425 * 1.9;
			color.rgb += vec3(0.30, 0.38, 0.55) * max(moonRing425, 0.0) * 0.7;
		#endif

		#ifdef FOURHUNDREDTWENTYSIX
			vec3 nViewPos426 = normalize(viewPos.xyz);
			float skyMix426 = clamp(dot(nViewPos426, upVec) * 0.5 + 0.5, 0.0, 1.0);
			vec3 skyBottom426 = vec3(0.045, 0.068, 0.095);
			vec3 skyTop426 = vec3(0.085, 0.118, 0.156);
			color.rgb = mix(skyBottom426, skyTop426, skyMix426);
			color.rgb += pow(1.0 - abs(dot(nViewPos426, upVec)), 1.5) * vec3(0.010, 0.016, 0.022);
			color.rgb *= vec3(0.92, 0.94, 0.96);
		#endif

		#ifdef FOURHUNDREDTWENTYSEVEN
			vec3 nViewPos427 = normalize(viewPos.xyz);
			float animTime427 = frameTimeCounter;
			float NdotU427 = dot(nViewPos427, upVec);
			float skyMix427 = clamp(NdotU427 * 0.5 + 0.5, 0.0, 1.0);
			vec3 skyBottom427 = vec3(0.008, 0.002, 0.014);
			vec3 skyTop427 = vec3(0.050, 0.013, 0.082);
			color.rgb = mix(skyBottom427, skyTop427, skyMix427);

			vec3 wpos427 = vec3(gbufferModelViewInverse * vec4(viewPos.xyz, 1.0));
			vec3 worldDir427 = normalize(wpos427);
			vec3 domeCoord427 = 0.75 * wpos427 / (abs(wpos427.y) + length(wpos427.xz) + 0.001);

			float upperSky427 = pow(max(worldDir427.y, 0.0), 0.65);
			vec2 starCoord427 = floor(domeCoord427.xz * 0.75 * 1536.0) / 1536.0;
			float starField427 = 1.0;
			starField427 *= GetNoise827(starCoord427 + vec2(0.13, 0.29));
			starField427 *= GetNoise827(starCoord427 * 1.91 + vec2(0.47, 0.11));
			starField427 *= GetNoise827(starCoord427 * 0.73 + vec2(0.05, 0.61));
			starField427 = max(starField427 - 0.84, 0.0);
			float twinkle427 = 0.75 + 0.25 * sin(animTime427 * 1.75 + dot(starCoord427, vec2(173.1, 91.7)) * 40.0);
			float starMask427 = starField427 * upperSky427 * twinkle427;
			color.rgb += vec3(1.30, 1.10, 1.45) * starMask427 * 9.0;

			vec2 nebCoord427 = domeCoord427.xz * vec2(7.5, 6.2) + vec2(animTime427 * 0.017, animTime427 * 0.008);
			float nebBase427 = FBM827(nebCoord427 + vec2(3.1, 7.4));
			float nebFine427 = FBM827(nebCoord427 * 2.15 + vec2(11.8, 2.7));
			float nebMask427 = smoothstep(0.56, 0.86, nebBase427 * 0.92 + nebFine427 * 0.42);
			nebMask427 *= upperSky427;
			vec3 nebCol427 = mix(vec3(0.16, 0.02, 0.04), vec3(0.75, 0.07, 0.12), nebFine427);
			color.rgb += nebCol427 * nebMask427 * 1.25;

			vec2 starUV427 = worldDir427.xz / (max(worldDir427.y, 0.001) + 0.05);
			float rot427 = animTime427 * 0.022;
			mat2 r427 = mat2(cos(rot427), -sin(rot427), sin(rot427), cos(rot427));
			vec2 hp427 = mat2(0.8660254, -0.5, 0.5, 0.8660254) * (r427 * (starUV427 * 1.04));

			const float kTri427 = 1.7320508;

			vec2 tUp427 = hp427;
			tUp427.x = abs(tUp427.x) - 1.0;
			tUp427.y = tUp427.y + 1.0 / kTri427;
			if (tUp427.x + kTri427 * tUp427.y > 0.0) tUp427 = vec2(tUp427.x - kTri427 * tUp427.y, -kTri427 * tUp427.x - tUp427.y) * 0.5;
			tUp427.x -= clamp(tUp427.x, -2.0, 0.0);
			float sdUp427 = -length(tUp427) * sign(tUp427.y);

			vec2 tDn427 = -hp427;
			tDn427.x = abs(tDn427.x) - 1.0;
			tDn427.y = tDn427.y + 1.0 / kTri427;
			if (tDn427.x + kTri427 * tDn427.y > 0.0) tDn427 = vec2(tDn427.x - kTri427 * tDn427.y, -kTri427 * tDn427.x - tDn427.y) * 0.5;
			tDn427.x -= clamp(tDn427.x, -2.0, 0.0);
			float sdDn427 = -length(tDn427) * sign(tDn427.y);

			float sdHexStar427 = min(sdUp427, sdDn427);
			float zenMask427 = smoothstep(0.30, 0.98, max(worldDir427.y, 0.0));
			float pulse427 = 0.72 + 0.28 * sin(animTime427 * 0.62);
			float starRing427 = (1.0 - smoothstep(0.000, 0.075, abs(sdHexStar427))) * zenMask427;
			float starFill427 = (1.0 - smoothstep(-0.20, 0.02, sdHexStar427)) * zenMask427;
			float starCore427 = (1.0 - smoothstep(-0.42, -0.12, sdHexStar427)) * zenMask427;
			float circleDist427 = abs(length(hp427) - 0.62);
			float circleRing427 = (1.0 - smoothstep(0.000, 0.045, circleDist427)) * zenMask427;
			float edgeNoise427 = FBM827(hp427 * 7.0 + vec2(5.2, 11.4) + vec2(animTime427 * 0.060, -animTime427 * 0.045));
			float edgeGlow427 = starRing427 * (0.75 + 0.75 * edgeNoise427);

			color.rgb += vec3(1.95, 0.10, 0.18) * edgeGlow427 * 1.55 * pulse427;
			color.rgb += vec3(1.30, 0.07, 0.14) * circleRing427 * 0.95 * pulse427;
			color.rgb += vec3(0.75, 0.05, 0.10) * starFill427 * 0.45 * pulse427;
			color.rgb *= 1.0 - starCore427 * (0.78 + 0.16 * edgeNoise427);
			color.rgb += vec3(0.36, 0.02, 0.05) * starCore427 * 0.18 * pulse427;

			color.rgb = min(color.rgb, vec3(3.5));
		#endif

		#ifdef FOURHUNDREDTWENTYFOUR
			vec3 nViewPos424 = normalize(viewPos.xyz);
			float skyMix424 = clamp(dot(nViewPos424, upVec) * 0.5 + 0.5, 0.0, 1.0);
			vec3 skyBottom424 = vec3(0.000, 0.000, 0.000);
			vec3 skyTop424 = vec3(0.003, 0.004, 0.006);
			color.rgb = mix(skyBottom424, skyTop424, skyMix424);
		#endif

		#ifdef EIGHTHUNDREDTWENTYNINE
			vec3 nViewPos829 = normalize(viewPos.xyz);
			float skyMix829 = clamp(dot(nViewPos829, upVec) * 0.5 + 0.5, 0.0, 1.0);
			vec3 skyBottom829 = vec3(0.012, 0.010, 0.000);
			vec3 skyTop829 = vec3(0.105, 0.078, 0.012);
			color.rgb = mix(skyBottom829, skyTop829, skyMix829);
			color.rgb += pow(1.0 - abs(dot(nViewPos829, upVec)), 1.45) * vec3(0.022, 0.016, 0.002);
			color.rgb *= vec3(0.90, 0.82, 0.55);
		#endif

		#ifdef EIGHTHUNDREDTWENTYSEVEN
			vec3 sceneSky827 = color.rgb;
			vec3 nViewPos827 = normalize(viewPos.xyz);
			NdotU = dot(nViewPos827, upVec);

			float skyMix827 = clamp(NdotU * 0.5 + 0.5, 0.0, 1.0);
			vec3 skyBottom827 = vec3(0.15, 0.035, 0.24);
			vec3 skyTop827 = vec3(0.03, 0.008, 0.08);
			color.rgb = mix(skyBottom827, skyTop827, skyMix827);

			float horizon827 = pow(1.0 - abs(NdotU), 1.9);
			color.rgb += horizon827 * vec3(0.065, 0.022, 0.10);

			// Keep overworld-style stars/galaxy structure from earlier sky passes,
			// then deepen to a darker purple grading for world827.
			vec3 retainedDetail827 = min(sceneSky827, vec3(1.3));
			retainedDetail827 = pow(retainedDetail827, vec3(1.06));
			color.rgb += retainedDetail827 * vec3(0.42, 0.24, 0.60);

			// Deferred-only nebula layer for world827 (mod renderer-safe).
			vec3 wpos827 = vec3(gbufferModelViewInverse * vec4(viewPos.xyz, 1.0));
			vec3 domeCoord827 = 0.75 * wpos827 / (abs(wpos827.y) + length(wpos827.xz) + 0.001);
			vec2 nebCoord827 = domeCoord827.xz * vec2(9.0, 7.0) + vec2(cloudtime * 0.00003, 0.0);
			float nebBase827 = FBM827(nebCoord827 + vec2(2.3, 5.1));
			float nebFine827 = FBM827(nebCoord827 * 2.1 + vec2(11.7, 3.8));
			float nebulaMask827 = smoothstep(0.62, 0.84, nebBase827 * 0.90 + nebFine827 * 0.35);
			nebulaMask827 *= pow(max(NdotU, 0.0), 0.8);
			vec3 nebulaCol827 = mix(vec3(0.18, 0.07, 0.30), vec3(0.34, 0.14, 0.52), nebFine827);
			color.rgb += nebulaCol827 * nebulaMask827 * 0.90;

			color.rgb *= vec3(0.83, 0.76, 0.92);

			float moonDot827 = dot(nViewPos827, -sunVec);
			float moonDisk827 = smoothstep(0.99882, 0.99958, moonDot827);
			float moonCore827 = smoothstep(0.99935, 0.99978, moonDot827);
			float moonRing827 = max(moonDisk827 - moonCore827, 0.0);
			color.rgb += vec3(0.74, 0.45, 1.00) * moonDisk827 * 2.35;
			color.rgb += vec3(0.58, 0.30, 0.92) * moonCore827 * 1.35;
			color.rgb += vec3(0.44, 0.18, 0.72) * moonRing827 * 1.55;
		#endif

		#ifdef EIGHTHUNDREDTWENTYONE
			color.rgb = vec3(0.0);
		#endif

		#ifdef END
			#ifdef ENDER_NEBULA
				color.rgb = enderNebula + nebulaStars;
				color.rgb += endCol * (0.035 + 0.02 * vsBrightness);
			#endif
		#endif

		#ifdef TWENTY
			color.rgb *= 0.1;
		#endif
		
		#ifdef SEVEN
			NdotU = max(dot(normalize(viewPos.xyz), upVec), 0.0);

			vec3 twilightPurple = vec3(0.005, 0.006, 0.018);
			vec3 twilightGreen = vec3(0.015, 0.03, 0.02);

			#ifdef TWENTY
				twilightPurple = twilightGreen * 0.1;
			#endif

			color.rgb = 2 * (twilightPurple * 2 * clamp(pow(NdotU, 0.7), 0.0, 1.0) + twilightGreen * (1-clamp(pow(NdotU, 0.7), 0.0, 1.0)));

			#ifndef TWENTY
				vec3 stars = DrawStars(color.rgb, viewPos.xyz, NdotU);
				color.rgb += stars.rgb;
			#endif
		#endif
		
		#ifdef TWO
			NdotU = 1.0 - max(dot(normalize(viewPos.xyz), upVec), 0.0);
			NdotU *= NdotU;
			#ifndef ABYSS
				vec3 midnightPurple = vec3(0.0003, 0.0004, 0.002) * 1.25;
				vec3 midnightFogColor = fogColor * fogColor * 0.3;
			#else
				vec3 midnightPurple = skyColor * skyColor * 0.00075;
				vec3 midnightFogColor = fogColor * fogColor * 0.09;
			#endif
			color.rgb = mix(midnightPurple, midnightFogColor, NdotU);
		#endif

		if (isEyeInWater == 1) {
			NdotU = max(dot(normalize(viewPos.xyz), upVec), 0.0);
			color.rgb = mix(color.rgb, 0.8 * pow(underwaterColor.rgb * (1.0 - blindFactor), vec3(2.0)), 1.0 - NdotU*NdotU);
		} else if (isEyeInWater == 2) {
			//duplicate 792763950
			#ifndef VANILLA_UNDERLAVA_COLOR
				vec3 lavaFogColor = vec3(0.6, 0.35, 0.15);
			#else
				vec3 lavaFogColor = pow(fogColor, vec3(2.2));
			#endif
			color.rgb = lavaFogColor;
		}
		if (blindFactor > 0.0) color.rgb *= 1.0 - blindFactor;
	}

	#ifdef BLACK_OUTLINE
		float wFogMult = 1.0 + eBS;
		BlackOutline(color.rgb, depthtex0, wFogMult);
	#endif

	#ifdef COLORED_LIGHT
		float sumlightAlbedo = max(lightAlbedo.r + lightAlbedo.g + lightAlbedo.b, 0.0001);
		vec3 lightAlbedoM = lightAlbedo / sumlightAlbedo;
		lightAlbedoM *= lightAlbedoM;
		lightAlbedoM *= BLOCKLIGHT_I * vec3(2.0, 1.8, 2.0);

		float lightSpeed = 0.01;
		vec3 lightBufferM = mix(lightBuffer, blocklightCol, lightSpeed * 0.25);
		vec3 finalLight = mix(lightBufferM, lightAlbedoM, lightSpeed * float(sumlightAlbedo > 0.0002));
	#endif
	
	/*DRAWBUFFERS:05*/
    gl_FragData[0] = color;
	gl_FragData[1] = vec4(pow(color.rgb, vec3(0.125)) * 0.5, 1.0);

	#ifdef COLORED_LIGHT
	/*DRAWBUFFERS:059*/
	gl_FragData[2] = vec4(finalLight, 1.0);
	#endif
}

#endif

//////////Vertex Shader//////////Vertex Shader//////////Vertex Shader//////////
#ifdef VSH

//Uniforms//
uniform mat4 gbufferModelView;

#ifdef COLORED_LIGHT
	uniform float viewHeight;

	uniform sampler2D colortex8;
	uniform sampler2D colortex9;
#endif

//Optifine Constants//

//Common Variables//
#if defined OVERWORLD && !defined EIGHTHUNDREDTWENTY && !defined EIGHTHUNDREDTWENTYONE && !defined EIGHTHUNDREDTWENTYFOUR && !defined EIGHTHUNDREDTWENTYSEVEN
	float timeAngleM = timeAngle;
#elif defined EIGHTHUNDREDTWENTY
	float timeAngleM = 0.35;
#elif defined EIGHTHUNDREDTWENTYONE
	float timeAngleM = 0.75;
#elif defined EIGHTHUNDREDTWENTYFOUR
	float timeAngleM = 0.75;
#elif defined EIGHTHUNDREDTWENTYSEVEN
float timeAngleM = 0.56;
#else
	#if !defined SEVEN && !defined SEVEN_2
		float timeAngleM = 0.25;
	#else
		float timeAngleM = 0.5;
	#endif
#endif

//Program//
void main() {
	texCoord = gl_MultiTexCoord0.xy;
	
	gl_Position = ftransform();

	const vec2 sunRotationData = vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
	float ang = fract(timeAngleM - 0.25);
	ang = (ang + (cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
	sunVec = normalize((gbufferModelView * vec4(vec3(-sin(ang), cos(ang) * sunRotationData) * 2000.0, 1.0)).xyz);

	upVec = normalize(gbufferModelView[1].xyz);

	#ifdef COLORED_LIGHT
		lightAlbedo = texture2DLod(colortex8, texCoord, log2(viewHeight)).rgb;
		lightBuffer = texture2D(colortex9, texCoord).rgb;
	#endif
}

#endif
