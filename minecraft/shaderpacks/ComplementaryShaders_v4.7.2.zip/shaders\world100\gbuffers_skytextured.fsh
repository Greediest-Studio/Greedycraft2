#version 130 

#define ONEHUNDRED
#define FSH

#define GBUFFERS_SKYTEXTURED

#include "/program/gbuffers_skytextured.glsl"

