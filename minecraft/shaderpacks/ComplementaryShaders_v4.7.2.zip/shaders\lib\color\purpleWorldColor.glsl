// Dimension 827 purple world color overrides
// Includes after lightColor.glsl to provide purple-specific colors

// Purple world base color (used in fog, sky, reflections)
vec3 purpleWorldCol = vec3(0.45, 0.1, 0.5);
