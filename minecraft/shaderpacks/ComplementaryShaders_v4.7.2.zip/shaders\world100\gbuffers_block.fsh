#version 130 

#define GBUFFERS_BLOCK
#define ONEHUNDRED
#define FSH

#include "/program/gbuffers_block.glsl"

