#if defined MOON_PHASE_LIGHTING && !defined UNIFORM_moonPhase
	#define UNIFORM_moonPhase
	uniform int moonPhase;
#endif

#ifndef MOON_PHASE_LIGHTING
	float nightBrightness = NIGHT_BRIGHTNESS;
#else
	float nightBrightness = moonPhase == 0 ? NIGHT_BRIGHTNESS * NIGHT_LIGHTING_FULL_MOON :
							moonPhase != 4 ? NIGHT_BRIGHTNESS * NIGHT_LIGHTING_PARTIAL_MOON :
											 NIGHT_BRIGHTNESS * NIGHT_LIGHTING_NEW_MOON;
#endif

vec3 lightMorning    = vec3(LIGHT_MR, LIGHT_MG, LIGHT_MB) * LIGHT_MI / 255.0;
vec3 lightDay        = vec3(LIGHT_DR, LIGHT_DG, LIGHT_DB) * LIGHT_DI / 255.0;
vec3 lightEvening    = vec3(LIGHT_ER, LIGHT_EG, LIGHT_EB) * LIGHT_EI / 255.0;
#ifdef EIGHTHUNDREDTWENTYTWO
vec3 lightNight      = vec3(0.12, 0.04, 0.02);  // Dark lava-world lighting
#elif defined EIGHTHUNDREDTWENTYONE
vec3 lightNight      = vec3(0.10, 0.10, 0.12);  // Dim lighting for void dimension
#elif defined DIM14676
vec3 lightNight      = vec3(0.12, 0.09, 0.18);  // Soft purple night tint for sparse stars
#else
#ifndef ONESEVEN
vec3 lightNight      = vec3(LIGHT_NR, LIGHT_NG, LIGHT_NB) * LIGHT_NI * (vsBrightness*0.125 + 0.80) * 0.4 / 255.0 * nightBrightness;
#else
vec3 lightNight      = (vec3(LIGHT_NR, LIGHT_NG, LIGHT_NB) * LIGHT_NI * 0.195 / 255.0) + vec3(0.37, 0.31, 0.25) * 0.35 ;
#endif
#endif

vec3 ambientMorning  = vec3(AMBIENT_MR, AMBIENT_MG, AMBIENT_MB) * AMBIENT_MI * 1.1 / 255.0;
vec3 ambientDay      = vec3(AMBIENT_DR, AMBIENT_DG, AMBIENT_DB) * AMBIENT_DI * 1.1 / 255.0;
vec3 ambientEvening  = vec3(AMBIENT_ER, AMBIENT_EG, AMBIENT_EB) * AMBIENT_EI * 1.1 / 255.0;
#ifdef EIGHTHUNDREDTWENTYTWO
vec3 ambientNight    = vec3(0.15, 0.06, 0.03);  // Dark lava-world ambient (overridden by lavaWorldColor)
#elif defined EIGHTHUNDREDTWENTYONE
vec3 ambientNight    = vec3(0.08, 0.08, 0.10);  // Dim ambient for void dimension
#else
vec3 ambientNight    = vec3(AMBIENT_NR, AMBIENT_NG, AMBIENT_NB) * AMBIENT_NI * (vsBrightness*0.20 + 0.70) * 0.495 / 255.0 * nightBrightness;
#endif

vec3 weatherCol = vec3(WEATHER_RR, WEATHER_RG, WEATHER_RB) * WEATHER_RI / 255.0;
vec3 weatherIntensity = vec3(WEATHER_RI);

float mefade = 1.0 - clamp(abs(timeAngle - 0.5) * 8.0 - 1.5, 0.0, 1.0);
float dfade = 1.0 - timeBrightness;
float dfadeM = dfade * dfade;
float dfadeM2 = 1.0 - dfade * dfade;

vec3 meL = mix(lightMorning, lightEvening, mefade);
vec3 dayAllL = mix(meL, lightDay, dfadeM2);
vec3 cL = mix(lightNight, dayAllL, sunVisibility);
vec3 cL2 = mix(cL, dot(cL, vec3(0.299, 0.587, 0.114)) * weatherCol * (vsBrightness*0.1 + 0.9), rainStrengthS*0.6);

vec3 meA = mix(ambientMorning, ambientEvening, mefade);
vec3 dayAllA = mix(meA, ambientDay, dfadeM2);
vec3 cA = mix(ambientNight, dayAllA, sunVisibility);
vec3 cA2 = mix(cA, dot(cA, vec3(0.299, 0.587, 0.114)) * weatherCol * (vsBrightness*0.1 + 0.9), rainStrengthS*0.6);

#ifdef EIGHTHUNDREDTWENTYSIX
float dualSunVisibility = abs(dot(sunVec, upVec));
float dualSunCurve = 0.45 + 0.55 * pow(dualSunVisibility, 1.25);
vec3 lightCol = vec3(0.95) * dualSunCurve;
vec3 ambientCol = vec3(0.80) * dualSunCurve;
#elif defined ONEHUNDREDTWO
float noonLightLevel102 = 15.0;
float noonAmbient102 = noonLightLevel102 / 15.0;
vec3 lightCol = vec3(0.68, 0.66, 0.62) * (0.42 + 0.58 * noonAmbient102);
vec3 ambientCol = vec3(0.18, 0.18, 0.17) * (0.55 + 0.95 * noonAmbient102);
#elif defined ONEHUNDREDONE
vec3 lightCol = vec3(0.105, 0.082, 0.178);
vec3 ambientCol = vec3(0.115, 0.088, 0.198);
#elif defined ONEHUNDRED
vec3 lightCol = vec3(0.070, 0.055, 0.120);
vec3 ambientCol = vec3(0.055, 0.042, 0.105);
#elif defined SEVENTYEIGHT
vec3 lightCol = vec3(0.030, 0.060, 0.125);
vec3 ambientCol = vec3(0.020, 0.035, 0.090);
#elif defined FOURHUNDREDTWENTYFIVE
vec3 lightCol = vec3(0.19, 0.23, 0.33);
vec3 ambientCol = vec3(0.14, 0.19, 0.30);
#elif defined FOURHUNDREDTWENTYSIX
vec3 lightCol = vec3(0.17, 0.21, 0.26);
vec3 ambientCol = vec3(0.11, 0.15, 0.21);
#elif defined FOURHUNDREDTWENTYSEVEN
vec3 lightCol = vec3(0.22, 0.27, 0.33);
vec3 ambientCol = vec3(0.18, 0.23, 0.30);
#elif defined FOURHUNDREDTWENTYFOUR
vec3 lightCol = vec3(0.24, 0.28, 0.36);
vec3 ambientCol = vec3(0.22, 0.26, 0.34);
#elif defined EIGHTHUNDREDTWENTYNINE
vec3 lightCol = vec3(0.42, 0.34, 0.12);
vec3 ambientCol = vec3(0.26, 0.21, 0.08);
#elif defined FOURHUNDREDTWENTY || defined FOURHUNDREDTWENTYONE || defined FOURHUNDREDTWENTYTWO || defined FOURHUNDREDTWENTYTHREE
	vec3 lightCol = lightDay * lightDay;
	vec3 ambientCol = ambientDay * ambientDay;
#else
vec3 lightCol = cL2 * cL2;
vec3 ambientCol = cA2 * cA2;
#endif