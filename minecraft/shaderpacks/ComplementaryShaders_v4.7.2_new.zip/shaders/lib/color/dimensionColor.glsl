#if defined OVERWORLD || defined SEVEN
#include "lightColor.glsl"
#endif

#ifdef NETHER
#include "netherColor.glsl"
#endif

#ifdef EIGHTHUNDREDTWENTY
#include "eucaWorldColor.glsl"
#endif

#ifdef EIGHTHUNDREDTWENTYFOUR
#include "corbaWorldColor.glsl"
#endif

#ifdef EIGHTHUNDREDTWENTYSEVEN
#include "purpleWorldColor.glsl"
#endif

#ifdef EIGHTHUNDREDTWENTYTWO
#include "lightColor.glsl"
#include "lavaWorldColor.glsl"
#endif

#ifdef EIGHTHUNDREDTWENTYONE
#include "lightColor.glsl"
#endif

#ifdef END
#include "endColor.glsl"
#endif

#ifdef SEVENTYEIGHT
#include "endColor.glsl"
#endif
